export interface DashboardData {
  user: {
    name: string;
    followers: string;
    following: string;
    profileImage: string;
  };
  metrics: {
    posts: number;
    interactions: string;
  };
  charts: {
    postsOverTime: Array<{ date: string; value: number }>;
    avgPostsPerDay: number;
    postTypeDist: Array<{ name: string; value: number }>;
    postsByPeriod: Array<{ name: string; value: number }>;
    postsByHourRange: Array<{ hour: string; value: number }>;
    hashtags: Array<{ name: string; value: number }>;
    heatmap: Array<{ hour: string; days: number[] }>; // 0-6 (Mon-Sun) values
  };
  cards: {
    topCommented: { value: number; image: string };
    topInteractions: { value: string; image: string };
  };
}

export interface ExportOptions {
  postsOverTime: boolean;
  avgPostsPerDay: boolean;
  postTypeDist: boolean;
  postsByPeriod: boolean;
  postsByHourRange: boolean;
  cards: boolean;
  hashtags: boolean;
  heatmap: boolean;
}