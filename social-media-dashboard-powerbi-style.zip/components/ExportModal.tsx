import React, { useState } from 'react';
import { ExportOptions } from '../types';
import { Icons } from './icons';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (options: ExportOptions) => void;
}

export const ExportModal: React.FC<Props> = ({ isOpen, onClose, onConfirm }) => {
  const [options, setOptions] = useState<ExportOptions>({
    postsOverTime: true,
    avgPostsPerDay: true,
    postTypeDist: true,
    postsByPeriod: true,
    postsByHourRange: true,
    cards: true,
    hashtags: true,
    heatmap: true,
  });

  if (!isOpen) return null;

  const handleToggle = (key: keyof ExportOptions) => {
    setOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSelectAll = () => {
    setOptions({
        postsOverTime: true,
        avgPostsPerDay: true,
        postTypeDist: true,
        postsByPeriod: true,
        postsByHourRange: true,
        cards: true,
        hashtags: true,
        heatmap: true,
    });
  };

  const handleDeselectAll = () => {
    setOptions({
        postsOverTime: false,
        avgPostsPerDay: false,
        postTypeDist: false,
        postsByPeriod: false,
        postsByHourRange: false,
        cards: false,
        hashtags: false,
        heatmap: false,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-5 border-b bg-slate-50 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-green-100 rounded-lg text-green-600">
               <Icons.FileSpreadsheet size={20} />
            </div>
            <h2 className="font-bold text-lg text-slate-800">Exportar Excel</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <span className="text-2xl leading-none">&times;</span>
          </button>
        </div>
        
        <div className="p-5 overflow-y-auto">
          <p className="text-sm text-slate-500 mb-4">Selecciona las métricas que deseas incluir en el reporte:</p>
          
          <div className="flex gap-3 mb-4 text-xs">
            <button onClick={handleSelectAll} className="text-blue-600 hover:underline font-medium">Seleccionar Todo</button>
            <span className="text-slate-300">|</span>
            <button onClick={handleDeselectAll} className="text-slate-500 hover:underline">Deseleccionar Todo</button>
          </div>

          <div className="space-y-3">
            <Checkbox label="Tendencia de Posts (28 días)" checked={options.postsOverTime} onChange={() => handleToggle('postsOverTime')} />
            <Checkbox label="Promedio Diario" checked={options.avgPostsPerDay} onChange={() => handleToggle('avgPostsPerDay')} />
            <Checkbox label="Distribución por Tipo" checked={options.postTypeDist} onChange={() => handleToggle('postTypeDist')} />
            <Checkbox label="Posts por Periodo (Día/Noche)" checked={options.postsByPeriod} onChange={() => handleToggle('postsByPeriod')} />
            <Checkbox label="Posts por Rango de Hora" checked={options.postsByHourRange} onChange={() => handleToggle('postsByHourRange')} />
            <Checkbox label="Flyers Destacados (Top)" checked={options.cards} onChange={() => handleToggle('cards')} />
            <Checkbox label="Hashtags Utilizados" checked={options.hashtags} onChange={() => handleToggle('hashtags')} />
            <Checkbox label="Heatmap Semanal" checked={options.heatmap} onChange={() => handleToggle('heatmap')} />
          </div>
        </div>

        <div className="p-5 border-t bg-slate-50 flex justify-end gap-3">
          <button 
            onClick={onClose} 
            className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-200 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          <button 
            onClick={() => onConfirm(options)} 
            className="px-6 py-2 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 shadow-md transition-all active:scale-95 flex items-center gap-2"
          >
            <Icons.Download size={16} />
            Descargar
          </button>
        </div>
      </div>
    </div>
  );
};

const Checkbox = ({ label, checked, onChange }: { label: string, checked: boolean, onChange: () => void }) => (
  <label className="flex items-center gap-3 p-3 border rounded-lg hover:bg-slate-50 cursor-pointer transition-colors group">
    <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${checked ? 'bg-blue-600 border-blue-600' : 'border-slate-300 group-hover:border-blue-400'}`}>
      {checked && <Icons.Check size={14} className="text-white" />}
    </div>
    <span className={`text-sm font-medium ${checked ? 'text-slate-800' : 'text-slate-500'}`}>{label}</span>
    <input type="checkbox" className="hidden" checked={checked} onChange={onChange} />
  </label>
);