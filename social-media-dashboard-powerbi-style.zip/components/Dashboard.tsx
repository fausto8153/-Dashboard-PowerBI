import React from 'react';
import { DashboardData } from '../types';
import { SimpleLineChart } from './charts/SimpleLineChart';
import { GaugeChart } from './charts/GaugeChart';
import { HorizontalBarChart } from './charts/HorizontalBarChart';
import { AreaChartComponent } from './charts/AreaChartComponent';
import { HeatMapComponent } from './charts/HeatMapComponent';

interface Props {
  data: DashboardData;
}

const Card: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className = "" }) => (
  <div className={`bg-white rounded-xl shadow-sm border border-slate-200 p-3 flex flex-col ${className}`}>
    <h3 className="text-xs text-slate-600 font-medium mb-2 text-center">{title}</h3>
    <div className="flex-1 min-h-0 relative">
      {children}
    </div>
  </div>
);

export const Dashboard: React.FC<Props> = ({ data }) => {
  // Capture logic moved to App.tsx/Sidebar.tsx, but ID 'dashboard-capture' remains for selection
  return (
    <div className="flex-1 h-screen overflow-hidden flex flex-col bg-slate-100" id="dashboard-capture">
      
      {/* Main Content Grid */}
      <main className="flex-1 p-4 overflow-y-auto overflow-x-hidden">
        <div className="max-w-[1600px] mx-auto flex flex-col gap-3 h-full">
          
          {/* Row 1: Charts */}
          <div className="grid grid-cols-12 gap-3 h-[280px]">
            {/* Post Trend */}
            <Card title="Cantidad de post realizados en los últimos - 28 Días" className="col-span-3">
               <SimpleLineChart data={data.charts.postsOverTime} />
            </Card>
            
            {/* Gauge */}
            <Card title="Promedio de publicaciones realizadas por día" className="col-span-2">
               <GaugeChart value={data.charts.avgPostsPerDay} />
            </Card>

            {/* Type Distribution */}
            <Card title="Distribución por tipo de post - 28 Días" className="col-span-2">
               <HorizontalBarChart data={data.charts.postTypeDist} />
            </Card>

            {/* Period Distribution */}
            <Card title="Numero de publicación por periodo en los ultimos- 28 Dias" className="col-span-2">
              <HorizontalBarChart data={data.charts.postsByPeriod} />
            </Card>

            {/* Hour Range */}
            <Card title="Numero de publicación por rango hora" className="col-span-3">
              <AreaChartComponent data={data.charts.postsByHourRange} />
            </Card>
          </div>

          {/* Row 2: Bottom Cards & Heatmap (Filters row removed) */}
          <div className="grid grid-cols-12 gap-3 h-[320px]">
             {/* Flyer Comments */}
             <Card title="Flyer con más comentarios" className="col-span-3">
                <div className="flex flex-col items-center justify-center h-full">
                  <img src={data.cards.topCommented.image} alt="Flyer" className="w-16 h-16 object-cover mb-2 rounded shadow-sm" />
                  <div className="text-xs text-red-500 font-bold mb-1">Total comentarios</div>
                  <div className="text-2xl font-bold text-yellow-500">{data.cards.topCommented.value}</div>
                </div>
             </Card>

             {/* Flyer Interactions */}
             <Card title="Flyer con más interacciones" className="col-span-3">
                <div className="flex flex-col items-center justify-center h-full">
                  <img src={data.cards.topInteractions.image} alt="Flyer" className="w-16 h-16 object-cover mb-2 rounded shadow-sm" />
                  <div className="text-xs text-red-500 font-bold mb-1">Total de interaccion</div>
                  <div className="text-2xl font-bold text-yellow-500">{data.cards.topInteractions.value}</div>
                </div>
             </Card>

             {/* Hashtags */}
             <Card title="# Utilizados - 28 Dias" className="col-span-2">
                <HorizontalBarChart data={data.charts.hashtags} />
             </Card>

             {/* Heatmap */}
             <Card title="Heatmap de Numero de publicación por hora y días de semanas en - 28 Días" className="col-span-4">
                <HeatMapComponent data={data.charts.heatmap} />
             </Card>
          </div>

        </div>
      </main>
    </div>
  );
};