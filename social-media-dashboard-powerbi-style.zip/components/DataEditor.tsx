import React, { useState, useRef, useEffect } from 'react';
import { DashboardData } from '../types';
import { Icons } from './icons';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  data: DashboardData;
  onSave: (newData: DashboardData) => void;
}

export const DataEditor: React.FC<Props> = ({ isOpen, onClose, data, onSave }) => {
  const [jsonText, setJsonText] = useState(JSON.stringify(data, null, 2));
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // History state for Undo/Redo
  const [history, setHistory] = useState<string[]>([]);
  const [currentStep, setCurrentStep] = useState<number>(-1);

  // Sync state when data changes or modal opens to ensure we edit the latest data
  useEffect(() => {
    if (isOpen) {
      const initialText = JSON.stringify(data, null, 2);
      setJsonText(initialText);
      setError(null);
      setSuccessMsg(null);
      
      // Initialize history
      setHistory([initialText]);
      setCurrentStep(0);
    }
  }, [data, isOpen]);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value;
    setJsonText(newText);
    setError(null);
    setSuccessMsg(null);

    // Add to history
    // We slice to current step to discard any "redo" history if we branch off
    const newHistory = history.slice(0, currentStep + 1);
    newHistory.push(newText);
    setHistory(newHistory);
    setCurrentStep(newHistory.length - 1);
  };

  const handleUndo = () => {
    if (currentStep > 0) {
      const prevStep = currentStep - 1;
      setJsonText(history[prevStep]);
      setCurrentStep(prevStep);
      setError(null);
      setSuccessMsg(null);
    }
  };

  const handleRedo = () => {
    if (currentStep < history.length - 1) {
      const nextStep = currentStep + 1;
      setJsonText(history[nextStep]);
      setCurrentStep(nextStep);
      setError(null);
      setSuccessMsg(null);
    }
  };

  const handleSave = () => {
    try {
      const parsed = JSON.parse(jsonText);
      onSave(parsed);
      onClose();
    } catch (e) {
      setError("Formato JSON inválido. Por favor corrige los errores.");
    }
  };

  const handleDownloadJson = () => {
     try {
        const blob = new Blob([jsonText], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.download = `dashboard-config-${new Date().toISOString().split('T')[0]}.json`;
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
     } catch(e) {
        setError("Error al descargar el archivo.");
     }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
     const file = e.target.files?.[0];
     if (!file) return;

     const reader = new FileReader();
     reader.onload = (event) => {
        try {
           const text = event.target?.result as string;
           // Validate JSON
           JSON.parse(text); 
           
           setJsonText(text);
           setError(null);
           setSuccessMsg("Configuración cargada correctamente.");
           
           // Update History
           const newHistory = history.slice(0, currentStep + 1);
           newHistory.push(text);
           setHistory(newHistory);
           setCurrentStep(newHistory.length - 1);

           // Reset file input so same file can be selected again if needed
           if (fileInputRef.current) fileInputRef.current.value = '';
        } catch (err) {
           setError("El archivo no es un JSON válido.");
        }
     };
     reader.readAsText(file);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-4xl h-[80vh] flex flex-col border border-slate-200">
        <div className="p-4 border-b flex justify-between items-center bg-slate-50 rounded-t-lg">
          <div className="flex items-center gap-2">
            <Icons.Settings className="text-slate-600" size={20} />
            <h2 className="font-bold text-lg text-slate-800">Editor de Datos (JSON)</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-slate-200 rounded-full transition-colors">
            <Icons.X size={20} />
          </button>
        </div>
        
        <div className="flex-1 p-4 overflow-hidden flex flex-col bg-slate-50/50">
          <div className="flex flex-wrap justify-between items-center mb-3 gap-2">
            <div className="flex items-center gap-2">
               <button 
                  onClick={handleUndo}
                  disabled={currentStep <= 0}
                  className={`p-2 rounded hover:bg-slate-200 transition-colors ${currentStep <= 0 ? 'text-slate-300' : 'text-slate-600'}`}
                  title="Deshacer (Undo)"
               >
                  <Icons.Undo size={18} />
               </button>
               <button 
                  onClick={handleRedo}
                  disabled={currentStep >= history.length - 1}
                  className={`p-2 rounded hover:bg-slate-200 transition-colors ${currentStep >= history.length - 1 ? 'text-slate-300' : 'text-slate-600'}`}
                  title="Rehacer (Redo)"
               >
                  <Icons.Redo size={18} />
               </button>
               <span className="text-sm text-slate-400 border-l border-slate-300 pl-2 ml-2 hidden sm:inline">
                   Historial: {currentStep + 1} / {history.length}
               </span>
            </div>

            <div className="flex gap-2">
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileUpload} 
                    accept=".json" 
                    className="hidden" 
                />
                <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 text-xs font-medium bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 px-3 py-2 rounded-lg transition-all shadow-sm"
                    title="Cargar configuración desde archivo JSON"
                >
                    <Icons.Upload size={14} className="text-blue-500" /> Importar
                </button>
                <button 
                    onClick={handleDownloadJson}
                    className="flex items-center gap-2 text-xs font-medium bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 px-3 py-2 rounded-lg transition-all shadow-sm"
                    title="Guardar configuración actual a archivo JSON"
                >
                    <Icons.Download size={14} className="text-green-500" /> Exportar
                </button>
            </div>
          </div>
          
          <div className="relative flex-1 rounded-lg border border-slate-300 overflow-hidden shadow-inner">
             <textarea
                className="w-full h-full font-mono text-xs p-4 bg-slate-900 text-green-400 focus:outline-none resize-none leading-relaxed"
                value={jsonText}
                spellCheck={false}
                onChange={handleTextChange}
              />
          </div>
          
          {(error || successMsg) && (
            <div className={`text-xs mt-2 px-3 py-2 rounded-md font-medium flex items-center gap-2 ${error ? 'bg-red-100 text-red-700 border border-red-200' : 'bg-green-100 text-green-700 border border-green-200'}`}>
               {error && <Icons.AlertCircle size={14} />}
               {successMsg && <Icons.Check size={14} />}
               {error || successMsg}
            </div>
          )}
        </div>

        <div className="p-4 border-t bg-slate-50 rounded-b-lg flex justify-end gap-3">
          <button 
            onClick={onClose} 
            className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-200 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          <button 
            onClick={handleSave} 
            className="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 shadow-md transition-all active:scale-95 flex items-center gap-2"
          >
            <Icons.Check size={16} />
            Aplicar Cambios
          </button>
        </div>
      </div>
    </div>
  );
};