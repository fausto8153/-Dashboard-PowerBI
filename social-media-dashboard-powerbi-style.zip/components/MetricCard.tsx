import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
}

export const MetricCard: React.FC<MetricCardProps> = ({ title, value, icon: Icon }) => {
  return (
    <div className="bg-white rounded-md shadow-sm border border-slate-200 p-3 flex items-center gap-4 w-48">
       <div className="border border-slate-300 p-2 rounded">
          <Icon size={24} className="text-slate-700" strokeWidth={1.5} />
       </div>
       <div>
         <div className="text-xs text-slate-500 mb-1">{title}</div>
         <div className="text-xl font-bold text-slate-800">{value}</div>
       </div>
    </div>
  );
};
