import React from 'react';
import { Home, Lightbulb, Facebook, Copy, MousePointerClick, Clock, ArrowUp, ArrowDown, Filter, ThumbsUp, MessageCircle, Download, Upload, Camera, FileSpreadsheet, Check, Settings, X, AlertCircle, Undo, Redo, Palette } from 'lucide-react';

export const Icons = {
  Home,
  Lightbulb,
  Facebook,
  Copy,
  MousePointerClick,
  Clock,
  ArrowUp,
  ArrowDown,
  Filter,
  ThumbsUp,
  MessageCircle,
  Download,
  Upload,
  Camera,
  FileSpreadsheet,
  Check,
  Settings,
  X,
  AlertCircle,
  Undo,
  Redo,
  Palette
};