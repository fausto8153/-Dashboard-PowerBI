import React, { useState, useRef, useEffect } from 'react';
import { Icons } from './icons';
import { DashboardData } from '../types';
import { askMarketingAssistant } from '../services/ai';

interface Props {
  data: DashboardData;
}

export const AIChatWidget: React.FC<Props> = ({ data }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [answer, setAnswer] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setAnswer(null);
    try {
      const response = await askMarketingAssistant(data, query);
      setAnswer(response);
    } catch (err) {
      setAnswer("Error al conectar con la IA.");
    } finally {
      setIsLoading(false);
    }
  };

  // Auto-resize textarea
  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setQuery(e.target.value);
    if (inputRef.current) {
        inputRef.current.style.height = 'auto';
        inputRef.current.style.height = inputRef.current.scrollHeight + 'px';
    }
  };

  return (
    <div className="w-full px-3 mb-2">
      <div className={`bg-slate-800 rounded-xl border border-blue-500/30 overflow-hidden transition-all duration-300 ${isOpen ? 'shadow-lg shadow-blue-900/20' : ''}`}>
        
        {/* Header / Toggle */}
        <button 
            onClick={() => setIsOpen(!isOpen)}
            className="w-full flex items-center justify-between p-3 bg-gradient-to-r from-blue-900/50 to-slate-800 hover:from-blue-800/50 transition-colors"
        >
            <div className="flex items-center gap-2 text-blue-300">
                <Icons.Lightbulb size={16} className={isOpen ? "text-yellow-400" : ""} />
                <span className="text-xs font-bold tracking-wide">IA INSIGHTS</span>
            </div>
            <Icons.ArrowDown size={14} className={`text-slate-500 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
        </button>

        {/* Content Area */}
        {isOpen && (
            <div className="p-3 bg-slate-900/50 border-t border-slate-700 animate-in slide-in-from-top-2">
                
                {/* Answer Display */}
                {answer && (
                    <div className="mb-3 p-2 bg-slate-800 rounded border border-slate-700 text-[10px] text-slate-300 leading-relaxed max-h-32 overflow-y-auto custom-scrollbar">
                        <div className="flex items-center gap-1 mb-1 text-blue-400 font-bold">
                            <Icons.MessageCircle size={10} /> Respuesta:
                        </div>
                        {answer}
                    </div>
                )}

                {/* Input Area */}
                <form onSubmit={handleSubmit} className="relative">
                    <textarea
                        ref={inputRef}
                        value={query}
                        onChange={handleInput}
                        placeholder="Pregunta sobre tus métricas..."
                        className="w-full bg-slate-950 text-slate-200 text-[11px] rounded-lg border border-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 p-2 pr-8 resize-none min-h-[36px] max-h-[80px] overflow-hidden"
                        rows={1}
                        onKeyDown={(e) => {
                            if(e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSubmit();
                            }
                        }}
                    />
                    <button 
                        type="submit" 
                        disabled={isLoading || !query.trim()}
                        className="absolute right-1.5 bottom-1.5 p-1 bg-blue-600 text-white rounded hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                        {isLoading ? <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Icons.ArrowUp size={12} />}
                    </button>
                </form>
                <div className="mt-2 flex flex-wrap gap-1.5">
                    {['Mejor hora para publicar', 'Análisis de Hashtags', 'Resumen de rendimiento'].map((suggestion) => (
                        <button 
                            key={suggestion}
                            onClick={() => { setQuery(suggestion); setTimeout(() => handleSubmit(), 0); }}
                            className="text-[9px] bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 px-2 py-1 rounded border border-slate-700 transition-colors truncate max-w-full"
                        >
                            {suggestion}
                        </button>
                    ))}
                </div>
            </div>
        )}
      </div>
    </div>
  );
};