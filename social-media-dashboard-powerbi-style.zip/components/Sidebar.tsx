import React, { useRef } from 'react';
import { Icons } from './icons';
import { DashboardData } from '../types';
import { AIChatWidget } from './AIChatWidget';

interface SidebarProps {
  data: DashboardData; // Changed from just 'user' to full 'DashboardData' for the AI
  onImageUpload: (file: File) => void;
  onExcelUpload: (file: File) => void;
  onExportExcel: () => void;
  onDownloadImage: () => void;
  isCapturing: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  data, 
  onImageUpload, 
  onExcelUpload, 
  onExportExcel, 
  onDownloadImage,
  isCapturing 
}) => {
  const imageInputRef = useRef<HTMLInputElement>(null);
  const excelInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) onImageUpload(file);
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  const handleExcelChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) onExcelUpload(file);
    if (excelInputRef.current) excelInputRef.current.value = '';
  };

  return (
    <aside className="w-64 bg-slate-900 h-screen flex flex-col items-center py-4 text-white shrink-0 sticky top-0 shadow-xl z-30">
      
      {/* App Title */}
      <div className="mb-4 text-xl font-bold tracking-wider text-blue-400 flex items-center gap-2">
        <Icons.FileSpreadsheet className="text-blue-500" />
        DASHBOARD
      </div>

      {/* AI Assistant Widget - Placed directly below dashboard title */}
      <AIChatWidget data={data} />

      <div className="w-full px-3 space-y-2 flex-1 flex flex-col overflow-y-auto custom-scrollbar">
        
        {/* Main Tab */}
        <button className="w-full bg-blue-600/90 hover:bg-blue-600 text-white font-bold py-2 rounded-lg shadow-md flex items-center pl-4 border-l-4 border-yellow-400 cursor-default transform transition-transform mb-2 text-xs">
          <Icons.Home className="mr-3 text-blue-200" size={16}/>
          CONTENIDOS
        </button>
        
        {/* Inputs Hidden */}
        <input type="file" ref={imageInputRef} className="hidden" accept="image/*" onChange={handleImageChange} />
        <input type="file" ref={excelInputRef} className="hidden" accept=".xlsx, .xls" onChange={handleExcelChange} />

        {/* Group: Entradas (Imports) & Capture */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
           <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest ml-1">Entradas</label>
           
           {/* 1. Importar Captura (IA) */}
           <button 
             onClick={() => imageInputRef.current?.click()}
             className="w-full group bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-medium py-2 rounded-lg transition-all duration-200 flex items-center pl-2 gap-2 border border-slate-700 hover:border-blue-500 shadow-sm text-xs"
           >
             <div className="p-1 bg-blue-500/20 rounded group-hover:bg-blue-600 transition-colors">
                <Icons.Camera size={14} className="text-blue-400 group-hover:text-white" />
             </div>
             <span>Importar Captura (IA)</span>
           </button>

           {/* 2. Importar Excel */}
           <button 
             onClick={() => excelInputRef.current?.click()}
             className="w-full group bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-medium py-2 rounded-lg transition-all duration-200 flex items-center pl-2 gap-2 border border-slate-700 hover:border-emerald-500 shadow-sm text-xs"
           >
             <div className="p-1 bg-emerald-500/20 rounded group-hover:bg-emerald-600 transition-colors">
                <Icons.Upload size={14} className="text-emerald-400 group-hover:text-white" />
             </div>
             <span>Importar Excel</span>
           </button>
        </div>

        {/* Group: Salidas (Exports) */}
        <div className="pt-2 space-y-2 border-t border-slate-800">
           <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest ml-1">Salidas</label>

            {/* 3. Descargar Foto */}
           <button 
             onClick={onDownloadImage}
             disabled={isCapturing}
             className="w-full group bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-medium py-2 rounded-lg transition-all duration-200 flex items-center pl-2 gap-2 border border-slate-700 hover:border-purple-500 shadow-sm text-xs"
           >
             <div className="p-1 bg-purple-500/20 rounded group-hover:bg-purple-600 transition-colors">
                <Icons.Download size={14} className="text-purple-400 group-hover:text-white" />
             </div>
             <span>
                {isCapturing ? "Generando..." : "Descargar Foto"}
             </span>
           </button>

           {/* 4. Exportar Excel */}
           <button 
             onClick={onExportExcel}
             className="w-full group bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-medium py-2 rounded-lg transition-all duration-200 flex items-center pl-2 gap-2 border border-slate-700 hover:border-green-500 shadow-sm text-xs"
           >
             <div className="p-1 bg-green-500/20 rounded group-hover:bg-green-600 transition-colors">
                <Icons.FileSpreadsheet size={14} className="text-green-400 group-hover:text-white" />
             </div>
             <span>Exportar Excel</span>
           </button>
        </div>
        
        <div className="mt-auto pt-2 border-t border-slate-800">
           <p className="text-[9px] text-slate-600 text-center leading-relaxed italic">
             Tu asistente IA analiza los datos cargados en tiempo real.
           </p>
        </div>
      </div>
    </aside>
  );
};