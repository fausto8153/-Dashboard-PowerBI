import React from 'react';
import { Icons } from './icons';

interface Props {
  isLoading: boolean;
}

export const LoadingOverlay: React.FC<Props> = ({ isLoading }) => {
  if (!isLoading) return null;

  return (
    <div className="fixed inset-0 bg-black/70 z-[60] flex flex-col items-center justify-center text-white backdrop-blur-sm">
      <div className="relative">
        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <Icons.Lightbulb className="text-yellow-400 animate-pulse" size={24} />
        </div>
      </div>
      <h2 className="mt-4 text-xl font-bold">Analizando Imagen con IA...</h2>
      <p className="text-slate-300 text-sm mt-2">Extrayendo métricas y generando dashboard</p>
    </div>
  );
};