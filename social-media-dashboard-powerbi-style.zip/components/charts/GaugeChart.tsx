import React from 'react';

interface Props {
  value: number;
  max?: number;
}

export const GaugeChart: React.FC<Props> = ({ value, max = 4.0 }) => {
  // Simple semi-circle gauge calculation
  const radius = 80;
  const stroke = 15;
  const normalizedValue = Math.min(Math.max(value, 0), max);
  const percentage = normalizedValue / max;
  
  // Calculate circumference for dasharray
  const circumference = Math.PI * radius;
  const dashOffset = circumference * (1 - percentage);

  return (
    <div 
      className="flex flex-col items-center justify-center h-full pt-4 cursor-default"
      title={`Promedio: ${value.toFixed(2)} / Meta: ${max.toFixed(2)}`}
    >
      <div className="relative w-48 h-28 flex justify-center overflow-hidden">
        <svg className="w-full h-full" viewBox="0 0 200 110">
          {/* Background Arc */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="#e5e7eb"
            strokeWidth={stroke}
            strokeLinecap="round"
          />
          {/* Value Arc */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="#ca8a04" // Yellow-600
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute bottom-0 text-center">
            <span className="text-4xl font-bold text-slate-600">{value.toFixed(2).replace('.', ',')}</span>
        </div>
      </div>
      <div className="flex justify-between w-full px-6 text-xs text-slate-400 -mt-2">
        <span>0,00</span>
        <span>{max.toFixed(2).replace('.', ',')}</span>
      </div>
    </div>
  );
};