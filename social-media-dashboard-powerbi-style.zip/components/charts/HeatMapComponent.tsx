import React, { useState, useMemo } from 'react';
import { Icons } from '../icons';

interface Props {
  data: Array<{ hour: string; days: number[] }>;
}

const DAYS = ['LUNES', 'MARTES', 'MIÉRCOLES', 'JUEVES', 'VIERNES', 'SÁBADO', 'DOMINGO'];
const SHORT_DAYS = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];

// Define available color palettes
const PALETTES = {
  blue: {
    name: 'Océano',
    colors: ['bg-slate-100', 'bg-blue-200', 'bg-blue-400', 'bg-blue-600', 'bg-blue-800'],
    preview: 'bg-blue-600'
  },
  green: {
    name: 'Esmeralda',
    colors: ['bg-slate-100', 'bg-emerald-200', 'bg-emerald-400', 'bg-emerald-600', 'bg-emerald-800'],
    preview: 'bg-emerald-600'
  },
  orange: {
    name: 'Fuego',
    colors: ['bg-slate-100', 'bg-orange-200', 'bg-orange-400', 'bg-orange-600', 'bg-orange-800'],
    preview: 'bg-orange-600'
  },
  purple: {
    name: 'Amatista',
    colors: ['bg-slate-100', 'bg-purple-200', 'bg-purple-400', 'bg-purple-600', 'bg-purple-800'],
    preview: 'bg-purple-600'
  }
};

type PaletteKey = keyof typeof PALETTES | 'custom';

export const HeatMapComponent: React.FC<Props> = ({ data }) => {
  const [selectedCell, setSelectedCell] = useState<{ day: string; hour: string; value: number; x: number; y: number } | null>(null);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // Customization State
  const [currentPalette, setCurrentPalette] = useState<PaletteKey>('blue');
  const [customColor, setCustomColor] = useState<string>('#ec4899'); // Default pink-500
  
  // Filter States
  const [selectedDayIndices, setSelectedDayIndices] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);
  
  // Extract available hours for the dropdowns
  const allHours = useMemo(() => data.map(d => d.hour), [data]);
  const [startHour, setStartHour] = useState<string>(allHours[0] || "");
  const [endHour, setEndHour] = useState<string>(allHours[allHours.length - 1] || "");

  // Update time range if data changes
  useMemo(() => {
    if (allHours.length > 0) {
        if (!allHours.includes(startHour)) setStartHour(allHours[0]);
        if (!allHours.includes(endHour)) setEndHour(allHours[allHours.length - 1]);
    }
  }, [allHours]);

  // Function to get color styling
  const getCellStyle = (value: number) => {
    // 0 values always slate-100/empty looking unless custom logic overrides, 
    // but to match style, we keep 0 as empty/light.
    if (value === 0) return { className: 'bg-slate-100' };

    if (currentPalette === 'custom') {
      let opacity = 1;
      if (value < 3) opacity = 0.3;
      else if (value < 6) opacity = 0.55;
      else if (value < 9) opacity = 0.8;
      else opacity = 1;

      return { 
        className: '', 
        style: { backgroundColor: customColor, opacity } 
      };
    }

    const colors = PALETTES[currentPalette as keyof typeof PALETTES].colors;
    let colorClass = colors[4];
    if (value < 3) colorClass = colors[1];
    else if (value < 6) colorClass = colors[2];
    else if (value < 9) colorClass = colors[3];
    
    return { className: colorClass };
  };

  const handleCellClick = (e: React.MouseEvent, day: string, hour: string, value: number) => {
    e.stopPropagation();
    const target = e.currentTarget as HTMLElement;
    const parent = target.closest('.heatmap-container');
    
    if (parent) {
        const rect = target.getBoundingClientRect();
        const parentRect = parent.getBoundingClientRect();
        
        setSelectedCell({
            day,
            hour,
            value,
            x: rect.left - parentRect.left + rect.width / 2,
            y: rect.top - parentRect.top
        });
    }
  };

  const toggleDay = (index: number) => {
    if (selectedDayIndices.includes(index)) {
        setSelectedDayIndices(selectedDayIndices.filter(i => i !== index));
    } else {
        setSelectedDayIndices([...selectedDayIndices, index].sort());
    }
  };

  const toggleAllDays = () => {
    if (selectedDayIndices.length === 7) {
        setSelectedDayIndices([]);
    } else {
        setSelectedDayIndices([0, 1, 2, 3, 4, 5, 6]);
    }
  };

  // Compute Filtered Data
  const { filteredRows, activeDays } = useMemo(() => {
    // 1. Filter Time Range
    const sIdx = allHours.indexOf(startHour);
    const eIdx = allHours.indexOf(endHour);
    const start = sIdx === -1 ? 0 : sIdx;
    const end = eIdx === -1 ? allHours.length - 1 : eIdx;
    
    const actualStart = Math.min(start, end);
    const actualEnd = Math.max(start, end);
    
    const rows = data.slice(actualStart, actualEnd + 1);

    // 2. Prepare Columns (just indices)
    return { filteredRows: rows, activeDays: selectedDayIndices };
  }, [data, allHours, startHour, endHour, selectedDayIndices]);

  return (
    <div 
        className="w-full h-full flex flex-col text-[10px] relative heatmap-container group" 
        onClick={() => {
            setSelectedCell(null);
            if(isFilterOpen) setIsFilterOpen(false);
        }}
    >
        {/* Filter Toggle Button */}
        <button 
            onClick={(e) => { e.stopPropagation(); setIsFilterOpen(!isFilterOpen); }}
            className={`absolute top-0 right-0 z-20 p-1.5 rounded-md transition-all ${isFilterOpen ? 'bg-blue-100 text-blue-600' : 'bg-transparent text-slate-400 hover:bg-slate-100'}`}
            title="Filtros y Configuración"
        >
            <div className="flex items-center gap-1">
              <Icons.Settings size={14} className={isFilterOpen ? "block" : "hidden group-hover:block"} />
              <Icons.Filter size={14} className={isFilterOpen ? "hidden" : "block group-hover:hidden"} />
            </div>
        </button>

        {/* Filter Panel */}
        {isFilterOpen && (
            <div 
                className="absolute top-8 right-0 z-30 bg-white shadow-xl border border-slate-200 rounded-lg p-3 w-64 animate-in fade-in zoom-in-95 duration-200"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="space-y-4">
                    
                    {/* Color Palette Selector */}
                    <div>
                        <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1">
                          <Icons.Palette size={12} /> Esquema de Color
                        </div>
                        <div className="flex flex-wrap gap-2">
                            {(Object.keys(PALETTES) as Array<keyof typeof PALETTES>).map((key) => (
                                <button
                                    key={key}
                                    onClick={() => setCurrentPalette(key)}
                                    className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${currentPalette === key ? 'ring-2 ring-slate-400 scale-110' : 'hover:scale-105'}`}
                                    title={PALETTES[key].name}
                                >
                                  <div className={`w-5 h-5 rounded-full border border-slate-200 shadow-sm ${PALETTES[key].preview}`}></div>
                                </button>
                            ))}
                            
                            {/* Custom Color Picker */}
                            <div className={`relative w-7 h-7 rounded-full flex items-center justify-center transition-all ${currentPalette === 'custom' ? 'ring-2 ring-slate-400 scale-110' : 'hover:scale-105'}`}>
                                <div className="w-5 h-5 rounded-full border border-slate-200 shadow-sm overflow-hidden relative">
                                  <input 
                                    type="color" 
                                    value={customColor}
                                    onChange={(e) => {
                                        setCustomColor(e.target.value);
                                        setCurrentPalette('custom');
                                    }}
                                    className="absolute inset-0 w-[150%] h-[150%] -top-1 -left-1 p-0 cursor-pointer border-none"
                                    title="Color personalizado"
                                  />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="h-px bg-slate-100 w-full my-2"></div>

                    {/* Day Selector (Checkboxes) */}
                    <div>
                        <div className="flex items-center justify-between mb-2">
                             <div className="text-xs font-semibold text-slate-700">Días</div>
                             <button 
                                 onClick={toggleAllDays}
                                 className="text-[10px] text-blue-600 hover:text-blue-700 font-medium"
                             >
                                 {selectedDayIndices.length === 7 ? 'Ninguno' : 'Todos'}
                             </button>
                        </div>
                        <div className="grid grid-cols-2 gap-y-2 gap-x-1">
                            {DAYS.map((d, i) => (
                                <button
                                    key={i}
                                    onClick={() => toggleDay(i)}
                                    className="flex items-center gap-2 group text-left"
                                >
                                    <div className={`w-3.5 h-3.5 rounded-[3px] border flex items-center justify-center transition-all ${selectedDayIndices.includes(i) ? 'bg-slate-800 border-slate-800' : 'bg-white border-slate-300 group-hover:border-slate-400'}`}>
                                        {selectedDayIndices.includes(i) && <Icons.Check size={10} className="text-white" />}
                                    </div>
                                    <span className={`text-[10px] ${selectedDayIndices.includes(i) ? 'text-slate-800 font-medium' : 'text-slate-500'}`}>
                                        {d.charAt(0).toUpperCase() + d.slice(1).toLowerCase()}
                                    </span>
                                </button>
                            ))}
                        </div>
                    </div>
                    
                    <div className="h-px bg-slate-100 w-full my-2"></div>

                    {/* Time Range Selector */}
                    <div>
                        <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1">
                            <Icons.Clock size={12} /> Rango Horario
                        </div>
                        <div className="flex items-center gap-2">
                            <select 
                                value={startHour} 
                                onChange={(e) => setStartHour(e.target.value)}
                                className="flex-1 bg-slate-50 border border-slate-200 rounded p-1 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-slate-700"
                            >
                                {allHours.map(h => <option key={h} value={h}>{h}</option>)}
                            </select>
                            <span className="text-slate-400 font-bold">-</span>
                            <select 
                                value={endHour} 
                                onChange={(e) => setEndHour(e.target.value)}
                                className="flex-1 bg-slate-50 border border-slate-200 rounded p-1 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-slate-700"
                            >
                                {allHours.map(h => <option key={h} value={h}>{h}</option>)}
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* Detail Popup */}
        {selectedCell && (
            <div 
                className="absolute z-50 bg-slate-900/95 backdrop-blur-sm text-white px-4 py-2.5 rounded-lg shadow-2xl border border-slate-700 pointer-events-none transform -translate-x-1/2 -translate-y-[calc(100%+12px)] transition-all duration-200 ease-out animate-in fade-in zoom-in-95"
                style={{ left: selectedCell.x, top: selectedCell.y }}
            >
                <div className="flex flex-col items-center gap-1.5 min-w-[90px]">
                    <div className="font-semibold text-[10px] text-slate-400 whitespace-nowrap border-b border-slate-700 pb-1.5 mb-0.5 w-full text-center flex items-center justify-center gap-2">
                        <span>{selectedCell.day}</span>
                        <span className="w-1 h-1 rounded-full bg-slate-600"></span>
                        <span>{selectedCell.hour}</span>
                    </div>
                    <div className="flex flex-col items-center">
                        <span className="text-2xl font-bold text-white leading-none tracking-tight font-mono">{selectedCell.value}</span>
                        <span className="text-[9px] text-slate-500 font-medium uppercase tracking-widest mt-0.5">Publicaciones</span>
                    </div>
                </div>
                
                {/* Arrow */}
                <div className="absolute left-1/2 -bottom-1.5 -translate-x-1/2 w-3 h-3 bg-slate-900 border-r border-b border-slate-700 rotate-45"></div>
            </div>
        )}

        {/* Header */}
        <div className="flex w-full mb-1 pr-6"> {/* Padding right to avoid overlap with filter button */}
            <div className="w-16 shrink-0 text-slate-400 font-medium pl-1 text-[9px] uppercase tracking-wider">Hora</div>
            <div className="flex-1 flex gap-1 text-center text-slate-500 font-semibold">
                {activeDays.map(dayIdx => (
                    <div key={DAYS[dayIdx]} className="flex-1">{SHORT_DAYS[dayIdx]}</div>
                ))}
            </div>
        </div>
        
        {/* Grid */}
        <div className="flex-1 flex flex-col justify-start overflow-y-auto pr-1 custom-scrollbar">
            {filteredRows.map((row, i) => (
                <div key={i} className="flex w-full items-center min-h-[20px] mb-1">
                    <div className="w-16 shrink-0 text-slate-400 leading-none truncate pr-2 text-right font-mono" title={row.hour}>{row.hour}</div>
                    <div className="flex-1 flex gap-1 h-full">
                        {activeDays.map((dayIdx) => {
                            const val = row.days[dayIdx];
                            const isSelected = selectedCell?.day === DAYS[dayIdx] && selectedCell?.hour === row.hour;
                            const { className, style } = getCellStyle(val);
                            
                            return (
                                <div 
                                  key={`${row.hour}-${dayIdx}`} 
                                  onClick={(e) => handleCellClick(e, DAYS[dayIdx], row.hour, val)}
                                  className={`flex-1 h-full rounded-sm ${className} transition-all cursor-pointer relative group border border-transparent hover:border-slate-400/50 hover:shadow-sm ${isSelected ? 'ring-2 ring-yellow-400 ring-offset-1 z-10' : ''}`}
                                  style={style}
                                  title={`${DAYS[dayIdx]} - ${row.hour}: ${val} publicaciones`}
                                >
                                </div>
                            );
                        })}
                    </div>
                </div>
            ))}
            
            {filteredRows.length === 0 && (
                 <div className="flex-1 flex items-center justify-center text-slate-400 italic">
                     No hay horas en este rango.
                 </div>
            )}
             {activeDays.length === 0 && (
                 <div className="absolute inset-0 flex items-center justify-center bg-white/50 backdrop-blur-[1px] text-slate-500 font-medium">
                     Selecciona al menos un día
                 </div>
            )}
        </div>
    </div>
  );
};