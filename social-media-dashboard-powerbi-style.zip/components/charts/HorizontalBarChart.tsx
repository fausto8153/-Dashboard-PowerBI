import React from 'react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LabelList, Tooltip } from 'recharts';

interface Props {
  data: Array<{ name: string; value: number }>;
  color?: string;
}

export const HorizontalBarChart: React.FC<Props> = ({ data, color = "#1e3a8a" }) => {
  return (
    <div className="w-full h-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          layout="vertical"
          data={data}
          margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
        >
          <Tooltip 
             cursor={{fill: 'transparent'}}
             contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
          />
          <XAxis type="number" hide />
          <YAxis 
            dataKey="name" 
            type="category" 
            axisLine={false} 
            tickLine={false}
            width={50}
            tick={{ fontSize: 11, fill: '#333', fontWeight: 500 }}
          />
          <Bar dataKey="value" fill={color} radius={[0, 4, 4, 0]} barSize={40}>
            <LabelList 
              dataKey="value" 
              position="right" 
              content={(props: any) => {
                 const { x, y, width, height, value } = props;
                 return (
                   <g transform={`translate(${x + width - 25},${y + height / 2})`}>
                     <rect x={-5} y={-10} width={24} height={20} rx={4} fill="#4338ca" />
                     <text x={7} y={4} fill="white" textAnchor="middle" fontSize={11} fontWeight="bold">{value}</text>
                   </g>
                 );
              }}
            />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};