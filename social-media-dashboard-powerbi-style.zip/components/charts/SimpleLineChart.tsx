import React from 'react';
import { LineChart, Line, XAxis, ResponsiveContainer, Tooltip, LabelList } from 'recharts';

interface Props {
  data: Array<{ date: string; value: number }>;
}

export const SimpleLineChart: React.FC<Props> = ({ data }) => {
  return (
    <div className="w-full h-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 20, right: 10, left: 10, bottom: 5 }}>
          <XAxis 
            dataKey="date" 
            tick={{ fontSize: 10, fill: '#666', angle: -90, textAnchor: 'end' }} 
            interval={0}
            height={60}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip 
            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
          />
          <Line 
            type="monotone" 
            dataKey="value" 
            stroke="#1e3a8a" 
            strokeWidth={2} 
            dot={{ r: 4, fill: '#1e3a8a' }}
          >
            <LabelList dataKey="value" position="top" style={{ fill: '#fff', fontSize: 10, fontWeight: 'bold' }} content={(props: any) => {
               const { x, y, value } = props;
               return (
                 <g transform={`translate(${x},${y})`}>
                   <rect x={-8} y={-18} width={16} height={14} fill="#4f46e5" rx={2} />
                   <text x={0} y={-8} fill="#fff" textAnchor="middle" fontSize={10}>{value}</text>
                 </g>
               );
            }}/>
          </Line>
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};