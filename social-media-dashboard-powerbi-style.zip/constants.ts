import { DashboardData } from './types';

export const INITIAL_DATA: DashboardData = {
  user: {
    name: "Admin User",
    followers: "20 mil",
    following: "3",
    profileImage: "https://picsum.photos/100/100"
  },
  metrics: {
    posts: 42,
    interactions: "32.170"
  },
  charts: {
    postsOverTime: [
      { date: 'Oct 24', value: 1 },
      { date: 'Oct 26', value: 1 },
      { date: 'Oct 30', value: 3 },
      { date: 'Oct 31', value: 3 },
      { date: 'Nov 01', value: 2 },
      { date: 'Nov 03', value: 1 },
      { date: 'Nov 05', value: 1 },
      { date: 'Nov 06', value: 1 },
      { date: 'Nov 07', value: 2 },
      { date: 'Nov 09', value: 3 },
      { date: 'Nov 10', value: 1 },
      { date: 'Nov 11', value: 3 },
      { date: 'Nov 12', value: 3 },
      { date: 'Nov 13', value: 2 },
      { date: 'Nov 14', value: 2 },
      { date: 'Nov 16', value: 2 },
      { date: 'Nov 17', value: 2 },
      { date: 'Nov 18', value: 3 },
    ],
    avgPostsPerDay: 2.00,
    postTypeDist: [
      { name: 'reel', value: 20 },
      { name: 'posts', value: 12 },
      { name: 'videos', value: 10 },
    ],
    postsByPeriod: [
      { name: 'Mañana', value: 16 },
      { name: 'Tarde', value: 13 },
      { name: 'Noche', value: 13 },
    ],
    postsByHourRange: [
      { hour: '07:00', value: 6 },
      { hour: '08:00', value: 2 },
      { hour: '09:00', value: 2 },
      { hour: '10:00', value: 4 },
      { hour: '11:00', value: 2 },
      { hour: '12:00', value: 4 },
      { hour: '13:00', value: 2 },
      { hour: '14:00', value: 1 },
      { hour: '15:00', value: 2 },
      { hour: '16:00', value: 2 },
      { hour: '17:00', value: 2 },
      { hour: '18:00', value: 2 },
      { hour: '19:00', value: 3 },
      { hour: '20:00', value: 2 },
      { hour: '21:00', value: 4 },
      { hour: '22:00', value: 1 },
      { hour: '23:00', value: 2 },
    ],
    hashtags: [
      { name: '#envivo', value: 8 },
      { name: '#crecemosjuntos', value: 3 },
      { name: '#megahidro', value: 1 },
    ],
    // Simulating heatmap data: rows are hours, array is Mon-Sun intensity (0-10)
    heatmap: [
      { hour: '07:00 AM', days: [10, 10, 2, 2, 2, 0, 0] },
      { hour: '08:00 AM', days: [0, 0, 0, 0, 8, 0, 0] },
      { hour: '09:00 AM', days: [0, 0, 5, 0, 5, 5, 0] },
      { hour: '10:00 AM', days: [0, 0, 0, 8, 0, 0, 0] },
      { hour: '11:00 AM', days: [0, 0, 0, 0, 0, 10, 10] },
      { hour: '12:00 PM', days: [0, 5, 5, 5, 0, 5, 5] },
      { hour: '01:00 PM', days: [0, 0, 0, 0, 8, 0, 0] },
      { hour: '02:00 PM', days: [5, 0, 0, 0, 0, 0, 0] },
      { hour: '03:00 PM', days: [5, 0, 0, 0, 5, 0, 0] },
      { hour: '04:00 PM', days: [0, 0, 8, 0, 0, 0, 0] },
      { hour: '05:00 PM', days: [0, 0, 0, 0, 5, 0, 5] },
      { hour: '06:00 PM', days: [5, 5, 0, 0, 0, 0, 0] },
      { hour: '07:00 PM', days: [5, 0, 0, 0, 0, 0, 5] },
      { hour: '08:00 PM', days: [0, 5, 5, 5, 0, 0, 5] },
      { hour: '09:00 PM', days: [0, 5, 0, 0, 0, 0, 0] },
      { hour: '10:00 PM', days: [0, 0, 0, 0, 0, 5, 5] },
      { hour: '11:00 PM', days: [0, 0, 0, 0, 0, 5, 0] },
    ]
  },
  cards: {
    topCommented: { value: 688, image: "https://picsum.photos/150/150?random=1" },
    topInteractions: { value: "3 mil", image: "https://picsum.photos/150/150?random=2" }
  }
};
