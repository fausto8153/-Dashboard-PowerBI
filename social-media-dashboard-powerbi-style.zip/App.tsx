import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { DataEditor } from './components/DataEditor';
import { ExportModal } from './components/ExportModal';
import { LoadingOverlay } from './components/LoadingOverlay';
import { INITIAL_DATA } from './constants';
import { DashboardData, ExportOptions } from './types';
import { Settings } from 'lucide-react';
import { analyzeImageAndGetData, fileToBase64 } from './services/ai';
import { exportToExcel, importFromExcel } from './services/excel';

const App: React.FC = () => {
  const [data, setData] = useState<DashboardData>(INITIAL_DATA);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);

  const handleImageUpload = async (file: File) => {
    setIsLoading(true);
    try {
      const base64 = await fileToBase64(file);
      const newData = await analyzeImageAndGetData(base64, data);
      
      const mergedData = {
        ...data,
        ...newData,
        user: { ...data.user, ...newData.user },
        metrics: { ...data.metrics, ...newData.metrics },
        charts: { ...data.charts, ...newData.charts },
        cards: { ...data.cards, ...newData.cards }
      };
      
      setData(mergedData);
    } catch (error) {
      console.error("Failed to process image", error);
      alert("Hubo un error al procesar la imagen con IA. Por favor intenta de nuevo.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleExcelUpload = async (file: File) => {
    setIsLoading(true);
    try {
      const parsedData = await importFromExcel(file);
      
      // Deep merge to keep structure valid
      const mergedData: DashboardData = {
        ...data,
        metrics: { ...data.metrics, ...parsedData.metrics },
        charts: { ...data.charts, ...parsedData.charts },
        cards: { ...data.cards, ...parsedData.cards }
      };
      
      setData(mergedData);
    } catch (error) {
      console.error("Excel import failed", error);
      alert("Hubo un error al leer el archivo Excel. Asegúrate que sea el formato correcto.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportClick = () => {
    setIsExportModalOpen(true);
  };

  const handleConfirmExport = (options: ExportOptions) => {
    try {
      exportToExcel(data, options);
      setIsExportModalOpen(false);
    } catch (error) {
      console.error("Excel export failed", error);
      alert("Hubo un error al exportar el Excel.");
    }
  };

  const handleDownloadImage = async () => {
    const element = document.getElementById('dashboard-capture');
    if (element && (window as any).html2canvas) {
      try {
        setIsCapturing(true);
        const canvas = await (window as any).html2canvas(element, {
          scale: 2, 
          backgroundColor: '#f1f5f9', 
          useCORS: true 
        });
        
        const link = document.createElement('a');
        link.download = `dashboard-report-${new Date().toISOString().split('T')[0]}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
      } catch (err) {
        console.error("Screenshot failed", err);
        alert("Could not generate image.");
      } finally {
        setIsCapturing(false);
      }
    } else {
        alert("Error: Librería de captura no cargada.");
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 font-sans text-slate-800">
      <LoadingOverlay isLoading={isLoading} />
      
      <Sidebar 
        data={data} // Pass full data for AI
        onImageUpload={handleImageUpload} 
        onExcelUpload={handleExcelUpload}
        onExportExcel={handleExportClick}
        onDownloadImage={handleDownloadImage}
        isCapturing={isCapturing}
      />
      <Dashboard data={data} />
      
      {/* Edit Data Button */}
      <button 
        onClick={() => setIsEditorOpen(true)}
        className="fixed bottom-6 right-6 bg-slate-800 text-white p-3 rounded-full shadow-lg hover:bg-slate-700 transition-all hover:scale-110 z-50 group"
        title="Edit Dashboard Data"
      >
        <Settings size={24} />
        <span className="absolute right-full mr-2 top-1/2 -translate-y-1/2 bg-black text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap transition-opacity">
          Edit Data
        </span>
      </button>

      <DataEditor 
        isOpen={isEditorOpen} 
        onClose={() => setIsEditorOpen(false)} 
        data={data} 
        onSave={setData} 
      />

      <ExportModal 
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        onConfirm={handleConfirmExport}
      />
    </div>
  );
};

export default App;