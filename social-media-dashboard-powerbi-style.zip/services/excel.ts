import { DashboardData, ExportOptions } from "../types";

declare global {
  interface Window {
    XLSX: any;
  }
}

// Helper to safely parse numbers from Excel (handles strings with commas, etc.)
const parseNum = (val: any): number => {
  if (typeof val === 'number') return val;
  if (!val) return 0;
  // Replace comma with dot if user typed "1,5" instead of "1.5"
  const str = val.toString().replace(',', '.');
  const num = parseFloat(str);
  return isNaN(num) ? 0 : num;
};

// Helper to safely get string
const parseStr = (val: any): string => {
  return val ? val.toString() : "";
};

export const exportToExcel = (data: DashboardData, options?: ExportOptions) => {
  if (!window.XLSX) {
    console.error("SheetJS not loaded");
    return;
  }

  // Default options
  const opts = options || {
    postsOverTime: true,
    avgPostsPerDay: true,
    postTypeDist: true,
    postsByPeriod: true,
    postsByHourRange: true,
    cards: true,
    hashtags: true,
    heatmap: true,
  };

  const aoa: any[][] = [];
  const addSpacing = () => aoa.push([""]);

  // --- HEADER & USER INFO (Always Exported for Data Integrity) ---
  aoa.push(["REPORTE DE DASHBOARD - " + data.user.name.toUpperCase()]);
  aoa.push(["Fecha de reporte:", new Date().toLocaleDateString()]);
  addSpacing();

  aoa.push(["0. INFORMACIÓN DE PERFIL Y MÉTRICAS"]);
  aoa.push(["Campo", "Valor"]);
  aoa.push(["Nombre Usuario", data.user.name]);
  aoa.push(["Seguidores", data.user.followers]);
  aoa.push(["Seguidos", data.user.following]);
  aoa.push(["Avatar URL", data.user.profileImage]);
  aoa.push(["Total Posts (Métrica)", data.metrics.posts]);
  aoa.push(["Interacciones Totales", data.metrics.interactions]);
  addSpacing();

  // --- 1. Cantidad de post realizados en los últimos - 28 Días ---
  if (opts.postsOverTime) {
    aoa.push(["1. CANTIDAD DE POST REALIZADOS EN LOS ÚLTIMOS - 28 DÍAS"]);
    aoa.push(["Fecha", "Cantidad"]); 
    data.charts.postsOverTime.forEach(item => {
        aoa.push([item.date, item.value]);
    });
    addSpacing();
  }

  // --- 2. Promedio de publicaciones ---
  if (opts.avgPostsPerDay) {
    aoa.push(["2. PROMEDIO DE PUBLICACIONES REALIZADAS POR DÍA"]);
    aoa.push(["Promedio Diario", data.charts.avgPostsPerDay]);
    addSpacing();
  }

  // --- 3. Distribución por tipo ---
  if (opts.postTypeDist) {
    aoa.push(["3. DISTRIBUCIÓN POR TIPO DE POST - 28 DÍAS"]);
    aoa.push(["Tipo", "Cantidad"]);
    data.charts.postTypeDist.forEach(item => {
        aoa.push([item.name, item.value]);
    });
    addSpacing();
  }

  // --- 4. Por Periodo ---
  if (opts.postsByPeriod) {
    aoa.push(["4. NUMERO DE PUBLICACIÓN POR PERIODO EN LOS ULTIMOS - 28 DIAS"]);
    aoa.push(["Periodo", "Cantidad"]);
    data.charts.postsByPeriod.forEach(item => {
        aoa.push([item.name, item.value]);
    });
    addSpacing();
  }

  // --- 5. Rango Hora ---
  if (opts.postsByHourRange) {
    aoa.push(["5. NUMERO DE PUBLICACIÓN POR RANGO HORA"]);
    aoa.push(["Hora", "Cantidad"]);
    data.charts.postsByHourRange.forEach(item => {
        aoa.push([item.hour, item.value]);
    });
    addSpacing();
  }

  // --- 6 & 7. Cards ---
  if (opts.cards) {
    aoa.push(["6. FLYER CON MÁS COMENTARIOS"]);
    aoa.push(["Valor", data.cards.topCommented.value]);
    aoa.push(["Imagen URL", data.cards.topCommented.image]);
    addSpacing();

    aoa.push(["7. FLYER CON MÁS INTERACCIONES"]);
    aoa.push(["Valor", data.cards.topInteractions.value]);
    aoa.push(["Imagen URL", data.cards.topInteractions.image]);
    addSpacing();
  }

  // --- 8. Hashtags ---
  if (opts.hashtags) {
    aoa.push(["8. # UTILIZADOS - 28 DIAS"]);
    aoa.push(["Hashtag", "Uso"]);
    data.charts.hashtags.forEach(item => {
        aoa.push([item.name, item.value]);
    });
    addSpacing();
  }

  // --- 9. Heatmap ---
  if (opts.heatmap) {
    aoa.push(["9. HEATMAP DE NUMERO DE PUBLICACIÓN POR HORA Y DÍAS"]);
    // Headers matching the short days logic or full days
    const heatmapHeaders = ['Hora', 'LUNES', 'MARTES', 'MIÉRCOLES', 'JUEVES', 'VIERNES', 'SÁBADO', 'DOMINGO'];
    aoa.push(heatmapHeaders);
    
    data.charts.heatmap.forEach(row => {
        // row.days is array of 7 numbers
        aoa.push([row.hour, ...row.days]);
    });
  }

  // --- Create File ---
  const wb = window.XLSX.utils.book_new();
  const ws = window.XLSX.utils.aoa_to_sheet(aoa);

  // Styling columns width for better readability
  const wscols = [
    { wch: 30 }, // Col A
    { wch: 15 }, // Col B
    { wch: 15 }, 
    { wch: 15 }, 
    { wch: 15 },
    { wch: 15 }, 
    { wch: 15 }, 
    { wch: 15 }, 
  ];
  ws['!cols'] = wscols;

  window.XLSX.utils.book_append_sheet(wb, ws, "Datos Dashboard");

  // Generate Filename
  const safeName = data.user.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  const fileName = `dashboard_${safeName}_${new Date().toISOString().split('T')[0]}.xlsx`;
  window.XLSX.writeFile(wb, fileName);
};

export const importFromExcel = async (file: File): Promise<Partial<DashboardData>> => {
  if (!window.XLSX) {
    throw new Error("SheetJS not loaded");
  }

  const arrayBuffer = await file.arrayBuffer();
  const wb = window.XLSX.read(arrayBuffer);
  const sheetName = wb.SheetNames[0];
  const ws = wb.Sheets[sheetName];
  
  // Read as Array of Arrays
  const rawData: any[][] = window.XLSX.utils.sheet_to_json(ws, { header: 1 });

  // Initialize structure
  const result: any = {
    user: {},
    metrics: {},
    charts: {},
    cards: { topCommented: {}, topInteractions: {} }
  };

  // Helper to find row index containing specific text (trimming spaces)
  const findRow = (text: string) => rawData.findIndex(row => 
    row[0] && row[0].toString().trim().toUpperCase().includes(text.toUpperCase())
  );

  // Helper to read simple key-value lists until empty line or next section
  const readList = (startIdx: number, mapFn: (row: any[]) => any) => {
    const items = [];
    let i = startIdx;
    // Look until end of file, or empty row, or next section (starts with number dot)
    while (i < rawData.length) {
      const row = rawData[i];
      // Stop if row is empty or first cell starts with a number (next section)
      if (!row || !row[0]) {
         i++; continue; // skip empty rows, but don't stop yet unless it's a gap
      }
      // Check if it's a new section header (e.g. "2. SOMETHING")
      if (/^\d+\./.test(row[0].toString())) break;

      items.push(mapFn(row));
      i++;
    }
    return items;
  };

  // --- 0. User Info ---
  const idx0 = findRow("0. INFORMACIÓN DE PERFIL");
  if (idx0 !== -1) {
    // Map of key -> row index relative to header
    // We scan the next 10 rows for keys
    for(let i = idx0 + 1; i < idx0 + 15; i++) {
        if(!rawData[i]) continue;
        const key = rawData[i][0]?.toString().toUpperCase();
        const val = rawData[i][1];
        
        if (key?.includes("NOMBRE USUARIO")) result.user.name = parseStr(val);
        if (key?.includes("SEGUIDORES")) result.user.followers = parseStr(val);
        if (key?.includes("SEGUIDOS")) result.user.following = parseStr(val);
        if (key?.includes("AVATAR URL")) result.user.profileImage = parseStr(val);
        if (key?.includes("TOTAL POSTS")) result.metrics.posts = parseNum(val);
        if (key?.includes("INTERACCIONES TOTALES")) result.metrics.interactions = parseStr(val);
    }
  }

  // --- 1. Posts Over Time ---
  const idx1 = findRow("1. CANTIDAD DE POST");
  if (idx1 !== -1) {
    // Skip header + subheader
    result.charts.postsOverTime = readList(idx1 + 2, (row) => ({
      date: parseStr(row[0]),
      value: parseNum(row[1])
    })).filter(item => item.date); // ensure validity
  }

  // --- 2. Avg Posts ---
  const idx2 = findRow("2. PROMEDIO DE PUBLICACIONES");
  if (idx2 !== -1) {
    // Value is usually in the row after header, col 1
    const row = rawData[idx2 + 1];
    if (row) result.charts.avgPostsPerDay = parseNum(row[1]);
  }

  // --- 3. Post Type Dist ---
  const idx3 = findRow("3. DISTRIBUCIÓN POR TIPO");
  if (idx3 !== -1) {
    result.charts.postTypeDist = readList(idx3 + 2, (row) => ({
      name: parseStr(row[0]),
      value: parseNum(row[1])
    })).filter(item => item.name);
  }

  // --- 4. Period ---
  const idx4 = findRow("4. NUMERO DE PUBLICACIÓN POR PERIODO");
  if (idx4 !== -1) {
    result.charts.postsByPeriod = readList(idx4 + 2, (row) => ({
      name: parseStr(row[0]),
      value: parseNum(row[1])
    })).filter(item => item.name);
  }

  // --- 5. Hour Range ---
  const idx5 = findRow("5. NUMERO DE PUBLICACIÓN POR RANGO");
  if (idx5 !== -1) {
    result.charts.postsByHourRange = readList(idx5 + 2, (row) => ({
      hour: parseStr(row[0]),
      value: parseNum(row[1])
    })).filter(item => item.hour);
  }

  // --- 6. Top Commented ---
  const idx6 = findRow("6. FLYER CON MÁS COMENTARIOS");
  if (idx6 !== -1) {
    result.cards.topCommented.value = parseNum(rawData[idx6 + 1]?.[1]);
    result.cards.topCommented.image = parseStr(rawData[idx6 + 2]?.[1]);
  }

  // --- 7. Top Interactions ---
  const idx7 = findRow("7. FLYER CON MÁS INTERACCIONES");
  if (idx7 !== -1) {
    result.cards.topInteractions.value = parseStr(rawData[idx7 + 1]?.[1]);
    result.cards.topInteractions.image = parseStr(rawData[idx7 + 2]?.[1]);
  }

  // --- 8. Hashtags ---
  const idx8 = findRow("8. # UTILIZADOS");
  if (idx8 !== -1) {
    result.charts.hashtags = readList(idx8 + 2, (row) => ({
      name: parseStr(row[0]),
      value: parseNum(row[1])
    })).filter(item => item.name);
  }

  // --- 9. Heatmap ---
  const idx9 = findRow("9. HEATMAP");
  if (idx9 !== -1) {
    const heatData = [];
    let i = idx9 + 2; // skip header and column names
    while (i < rawData.length) {
      const row = rawData[i];
      if (!row || !row[0]) { i++; continue; }
      if (/^\d+\./.test(row[0].toString())) break; // Next section check

      const hour = parseStr(row[0]);
      // Days are columns 1 to 7 (L to D)
      const days = [];
      for (let d = 1; d <= 7; d++) {
        days.push(parseNum(row[d]));
      }
      heatData.push({ hour, days });
      i++;
    }
    result.charts.heatmap = heatData;
  }

  return result;
};