import { GoogleGenAI } from "@google/genai";
import { DashboardData } from "../types";

// Helper to convert file to base64
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data url prefix (e.g. "data:image/jpeg;base64,")
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });
};

export const analyzeImageAndGetData = async (base64Image: string, currentData: DashboardData): Promise<DashboardData> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const schemaDescription = JSON.stringify(currentData, null, 2);

    const prompt = `
      Act as a Data Extraction AI. 
      Analyze the attached image which is a screenshot of social media analytics (Instagram, Facebook, TikTok, etc.).
      
      Your task is to extract the visible metrics and map them to the following JSON structure.
      
      Target JSON Structure:
      ${schemaDescription}

      Rules:
      1. Extract exact numbers where visible (e.g., Followers, Posts, Interactions).
      2. If specific charts (like "postsByHourRange" or "heatmap") are not explicitly detailed in the image, GENERATE REALISTIC ESTIMATES based on the aggregate numbers you found. 
      3. For "user.profileImage", keep the existing URL or use a placeholder if not detecting a face.
      4. For "cards", pick the most prominent post or interaction metric found in the image.
      5. Return ONLY the valid JSON object. Do not include markdown formatting like \`\`\`json.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const parsedData = JSON.parse(text);
    return parsedData as DashboardData;

  } catch (error) {
    console.error("Error analyzing image:", error);
    throw error;
  }
};

export const askMarketingAssistant = async (data: DashboardData, question: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const dataContext = JSON.stringify(data, null, 2);

    const prompt = `
      Eres un Experto Analista de Marketing Digital y Redes Sociales (Social Media Manager).
      Tu objetivo es responder preguntas sobre el rendimiento basándote EXCLUSIVAMENTE en los datos del dashboard proporcionado.

      DATOS DEL DASHBOARD (JSON):
      ${dataContext}

      PREGUNTA DEL USUARIO:
      "${question}"

      INSTRUCCIONES AVANZADAS DE ANÁLISIS:
      1. **Navegación por los Datos**:
         - **Hashtags**: Revisa 'charts.hashtags'. Si preguntan "cuál funcionó mejor", busca el de mayor 'value'.
         - **Top Posts/Flyers**: Revisa 'cards.topCommented' y 'cards.topInteractions' para identificar contenido de alto rendimiento.
         - **Tendencias Temporales**: Analiza 'charts.postsOverTime'. Si el usuario pregunta por un mes específico (ej. "Mayo") y los datos son de "Octubre", **ACLARA** qué rango de fechas estás viendo antes de responder.
         - **Horarios y Días**: Cruza la información de 'charts.heatmap' (intensidad por hora/día) con 'charts.postsByHourRange' para dar recomendaciones precisas de publicación.

      2. **Interpretación de Preguntas**:
         - Si la pregunta es específica (ej. "¿Qué hashtag usé más?"), da el dato exacto del JSON.
         - Si la pregunta es abierta (ej. "¿Cómo mejorar?"), busca métricas con valores bajos (ej. días con 0 actividad en el heatmap) y sugiere acciones.

      3. **Formato de Respuesta**:
         - Responde de manera profesional, estratégica y concisa.
         - **Usa negritas** para destacar las métricas clave (ej. "**#envivo** tuvo **8** usos").
         - No inventes información que no esté en el JSON.

      EJEMPLOS DE RAZONAMIENTO:
      - Usuario: "¿Qué hashtag funcionó mejor?"
        AI: Busca el max valor en charts.hashtags. Respuesta: "El hashtag con mejor desempeño fue **[Nombre]** con **[Valor]** usos."
      - Usuario: "¿Cuál es mi mejor hora?"
        AI: Busca los valores más altos en charts.heatmap o charts.postsByHourRange. Respuesta: "Tus mejores horas son alrededor de las **[Hora]**, especialmente los [Día]."

      Genera tu respuesta ahora:
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt
    });

    return response.text || "No pude generar una respuesta en este momento.";

  } catch (error) {
    console.error("Error asking AI:", error);
    return "Lo siento, hubo un error al consultar con el asistente. Verifica tu conexión o intenta más tarde.";
  }
};